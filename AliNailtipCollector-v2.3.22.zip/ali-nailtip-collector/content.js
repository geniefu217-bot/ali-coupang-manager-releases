(() => {
  "use strict";

  if (window.__ALI_NAILTIP_COLLECTOR__) return;
  window.__ALI_NAILTIP_COLLECTOR__ = true;

  const state = {
    running: false,
    stop: false,
    results: [],
    links: [],
  };

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const sleep = async ms => {
    try { const response=await chrome.runtime.sendMessage({type:'ANTC_DELAY',ms});if(response?.ok)return; }
    catch { /* A restarted or older worker falls back to the ordinary page timer. */ }
    return new Promise(resolve=>setTimeout(resolve,ms));
  };
  const clean = (value) => String(value ?? "").replace(/\s+/g, " ").trim();
  const uniq = (items) => [...new Set(items.filter(Boolean))];

  function canonicalItemUrl(raw) {
    try {
      const url = new URL(raw, location.href);
      const match = url.pathname.match(/\/item\/(\d+)\.html/i);
      return match ? `https://ko.aliexpress.com/item/${match[1]}.html` : "";
    } catch {
      return "";
    }
  }

  function won(value) {
    const text = clean(value);
    const matches = [...text.matchAll(/(?:₩|KRW\s*)\s*([\d,]+)/gi)];
    if (!matches.length) return "";
    return Number(matches[0][1].replaceAll(",", "")) || "";
  }

  function numberLike(value) {
    if (typeof value === "number" && Number.isFinite(value)) return value;
    const text = clean(value);
    if (!/^\d+(?:\.\d+)?$/.test(text)) return null;
    const num = Number(text);
    return Number.isFinite(num) ? num : null;
  }

  function textFrom(root, selectors) {
    for (const selector of selectors) {
      const node = root.querySelector(selector);
      const value = clean(node?.getAttribute("content") || node?.textContent || "");
      if (value) return value;
    }
    return "";
  }

  function imageUrl(raw) {
    if (!raw) return "";
    let value = String(raw).trim().split(/\s+/)[0];
    if (value.startsWith("//")) value = `https:${value}`;
    if (!/^https?:\/\//i.test(value)) return "";
    const parsed = new URL(value);
    if (/(?:\.aliexpress-media\.com|\.alicdn\.com|\.aliexpress\.com)$/i.test(parsed.hostname)) {
      parsed.pathname = parsed.pathname.replace(/(\.(?:jpg|jpeg|png))_(?:\d+x\d+|Q\d+)[^/]*$/i, "$1");
      parsed.protocol = "https:";
      return parsed.href;
    }
    return value;
  }

  function nearestCard(link) {
    let node = link;
    let best = link.parentElement;
    for (let depth = 0; node && depth < 8; depth += 1, node = node.parentElement) {
      const text = clean(node.innerText);
      const itemLinks = node.querySelectorAll?.('a[href*="/item/"]').length || 0;
      const imgs = node.querySelectorAll?.("img").length || 0;
      const distinctItems = new Set([...(node.querySelectorAll?.('a[href*="/item/"]') || [])].map(a => canonicalItemUrl(a.href)).filter(Boolean));
      if (text.length >= 20 && text.length <= 800 && itemLinks <= 3 && distinctItems.size <= 1 && imgs >= 1) best = node;
    }
    return best || link;
  }

  async function autoScroll() {
    let stable = 0;
    let previous = 0;
    for (let i = 0; i < 18 && !state.stop; i += 1) {
      window.scrollTo({ top: document.documentElement.scrollHeight, behavior: "smooth" });
      await sleep(600);
      const current = document.querySelectorAll('a[href*="/item/"]').length;
      stable = current === previous ? stable + 1 : 0;
      previous = current;
      setStatus(`검색결과 불러오는 중…\n현재 상품 링크 ${current}개`);
      if (stable >= 3) break;
    }
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function scanSearchPage(choiceOnly) {
    const byUrl = new Map();
    const pageFilteredChoice = /(?:selectedSwitches=.*choice|filterCode%3Achoice|choice_atm)/i.test(location.href);

    for (const link of $$('a[href*="/item/"]')) {
      const url = canonicalItemUrl(link.href);
      if (!url || byUrl.has(url)) continue;
      const card = nearestCard(link);
      const cardText = clean(card?.innerText || "");
      const img = card?.querySelector("img") || link.querySelector("img");
      const title = clean(
        link.getAttribute("aria-label") || img?.getAttribute("alt") ||
        card?.querySelector("h1,h2,h3,[title]")?.getAttribute("title") || cardText
      ).slice(0, 300);
      const badgeText = [...(card?.querySelectorAll("img[alt], [aria-label], [title]") || [])].map(node => [node.getAttribute("alt"), node.getAttribute("aria-label"), node.getAttribute("title")].filter(Boolean).join(" ")).join(" ");
      const choice = /\bchoice\b|초이스/i.test(`${cardText} ${badgeText}`);
      if (choiceOnly && !choice) continue;
      if (/알뜰\s*마트|Dollar\s*Express|Bundle\s*deals/i.test(`${cardText} ${badgeText}`)) continue;
      byUrl.set(url, {
        source_url: url,
        search_title: title,
        search_price_krw: won(cardText),
        search_image: imageUrl(img?.currentSrc || img?.src || img?.getAttribute("data-src")),
        choice,
      });
    }
    if (!byUrl.size && !choiceOnly) {
      for (const match of document.documentElement.innerHTML.matchAll(/(?:\\?\/item\\?\/|%2Fitem%2F)(\d{8,})(?:\.html|%2Ehtml)/gi)) {
        const url = `https://ko.aliexpress.com/item/${match[1]}.html`;
        if (!byUrl.has(url)) {
          byUrl.set(url, {
            source_url: url,
            search_title: `AliExpress ${match[1]}`,
            search_price_krw: "",
            search_image: "",
            choice: pageFilteredChoice,
          });
        }
      }
    }
    return [...byUrl.values()];
  }

  function balancedObject(text, start) {
    let depth = 0;
    let quote = "";
    let escaped = false;
    for (let i = start; i < text.length; i += 1) {
      const ch = text[i];
      if (quote) {
        if (escaped) escaped = false;
        else if (ch === "\\") escaped = true;
        else if (ch === quote) quote = "";
        continue;
      }
      if (ch === '"' || ch === "'") { quote = ch; continue; }
      if (ch === "{") depth += 1;
      if (ch === "}") {
        depth -= 1;
        if (depth === 0) return text.slice(start, i + 1);
      }
    }
    return "";
  }

  function payloadsFromText(text, output) {
    if (text.length < 2 || text.length > 8_000_000) return;
    try {
      output.push(JSON.parse(text));
      return;
    } catch { /* assignment-style script */ }
    for (const match of text.matchAll(/JSON\.parse\(\s*("(?:\\.|[^"\\])*")\s*\)/g)) {
      try { output.push(JSON.parse(JSON.parse(match[1]))); } catch { /* Malformed embedded JSON. */ }
    }
    for (const marker of [
      "window.runParams", "runParams", "__INIT_DATA__", "__INITIAL_STATE__",
      "__NEXT_DATA__", "__AER_DATA__", "__AER_APP_DATA__", "data:"
    ]) {
      const position = text.indexOf(marker);
      if (position < 0) continue;
      const start = text.indexOf("{", position + marker.length);
      if (start < 0) continue;
      const candidate = balancedObject(text, start);
      if (!candidate) continue;
      try { output.push(JSON.parse(candidate)); } catch { /* ignore malformed payload */ }
    }
  }

  function jsonPayloads(doc, extraTexts = []) {
    const output = [];
    for (const script of $$('script[type="application/json"],script[type="application/ld+json"],script:not([src])', doc)) {
      const text = script.textContent || "";
      payloadsFromText(text, output);
    }
    for (const text of extraTexts) payloadsFromText(String(text || ""), output);
    return output;
  }

  function walk(value, visitor, path = [], seen = new WeakSet()) {
    if (path.length > 30) return;
    if (typeof value === "string" && value.length < 8_000_000) {
      const text = value.trim();
      if ((text.startsWith("{") && text.endsWith("}")) || (text.startsWith("[") && text.endsWith("]"))) {
        try { walk(JSON.parse(text), visitor, path, seen); } catch { /* Not JSON data. */ }
      }
      return;
    }
    if (!value || typeof value !== "object" || seen.has(value)) return;
    seen.add(value);
    visitor(value, path);
    if (Array.isArray(value)) value.forEach((item,index)=>walk(item,visitor,[...path,index],seen));
    else Object.entries(value).forEach(([key,item])=>walk(item,visitor,[...path,key],seen));
  }

  function firstValue(obj, keys) {
    for (const key of keys) {
      if (obj && Object.prototype.hasOwnProperty.call(obj, key)) {
        const value = obj[key];
        if (value !== undefined && value !== null && value !== "") return value;
      }
    }
    return null;
  }

  function deepString(value) {
    if (value == null) return "";
    if (typeof value === "string" || typeof value === "number") return clean(value);
    if (typeof value !== "object") return "";
    for (const key of ["value", "displayValue", "formattedPrice", "amount", "text", "name"]) {
      if (value[key] != null && typeof value[key] !== "object") return clean(value[key]);
    }
    return "";
  }

  function inventoryFrom(obj) {
    for (const key of ["skuVal", "skuValue"]) {
      if (obj?.[key] && typeof obj[key] === "object") {
        const nested=inventoryFrom(obj[key]);
        if (nested!==null) return nested;
      }
    }
    const raw = firstValue(obj, [
      "availQuantity", "availableQuantity", "inventory", "stock", "stockCount",
      "salableInventory", "skuStock", "sellableQuantity", "availableStock", "skuInventory"
    ]);
    if (raw == null) {
      const nested = firstValue(obj, ["skuVal", "skuValue", "inventoryInfo", "stockInfo"]);
      if (nested && typeof nested === "object") return inventoryFrom(nested);
    }
    if (raw && typeof raw === "object") {
      return numberLike(firstValue(raw, ["value", "quantity", "stock", "total", "available"]));
    }
    return numberLike(raw);
  }

  function priceFrom(obj) {
    const raw = firstValue(obj, [
      "actSkuCalPrice", "salePrice", "discountPrice", "skuAmount", "price", "formattedPrice"
    ]);
    if (raw == null) {
      const nested = firstValue(obj, ["skuVal", "skuValue", "priceInfo"]);
      if (nested && typeof nested === "object") return priceFrom(nested);
    }
    const text = deepString(raw);
    return won(text) || numberLike(text) || "";
  }

  function optionNameMap(payloads) {
    const names = new Map();
    for (const payload of payloads) {
      walk(payload, (obj) => {
        const propertyName = clean(firstValue(obj, ["skuPropertyName", "propertyName", "name"]));
        const values = firstValue(obj, ["skuPropertyValues", "propertyValues", "values"]);
        if (!propertyName || !Array.isArray(values)) return;
        for (const item of values) {
          const id = clean(firstValue(item, ["propertyValueIdLong", "propertyValueId", "id", "skuPropertyValueId"]));
          const label = clean(firstValue(item, ["propertyValueDisplayName", "propertyValueName", "displayName", "name"]));
          if (id && label) names.set(id, { propertyName, label, image: imageUrl(item.skuPropertyImagePath || item.imageUrl || "") });
        }
      });
    }
    return names;
  }

  function skuRows(payloads) {
    const optionMap = optionNameMap(payloads);
    const candidates = [];
    const seen = new Set();

    for (const payload of payloads) {
      walk(payload, (obj, path) => {
        if (!Object.hasOwn(obj,"skuId") && !Object.hasOwn(obj,"skuIdStr") && !Object.hasOwn(obj,"sku_id") && !/skuPriceList|skuList/i.test(path.join("."))) return;
        const skuId = clean(firstValue(obj, ["skuId", "skuIdStr", "id", "sku_id"]));
        const propIds = clean(firstValue(obj, ["skuPropIds", "skuAttr", "skuAttrs", "props", "propertyValueIds"]));
        const stock = inventoryFrom(obj);
        const price = priceFrom(obj);
        if (!skuId && !propIds) return;
        if (stock === null && !price) return;
        const key = `${skuId}|${propIds}|${stock}|${price}`;
        if (seen.has(key)) return;
        seen.add(key);

        const optionParts = [];
        let skuImage = "";
        for (const token of propIds.split(/[;,|]/).map((v) => v.trim()).filter(Boolean)) {
          const idToken = token.split("#")[0];
          const direct = optionMap.get(idToken);
          const tail = optionMap.get(idToken.split(":").pop());
          const found = direct || tail;
          if (found) { optionParts.push(`${found.propertyName}: ${found.label}`); skuImage ||= found.image; }
          else if (token.includes("#")) optionParts.push(clean(token.split("#").slice(1).join("#").replaceAll("+", " ")));
        }
        candidates.push({
          sku_id: skuId,
          sku_attr: propIds,
          option: uniq(optionParts).join(" / ") || propIds,
          stock,
          price_krw: price,
          main_image: skuImage,
        });
      });
    }
    return candidates;
  }

  function detailImages(doc, payloads) {
    const images = [];
    const add = value => {
      if (Array.isArray(value)) { value.forEach(add); return; }
      if (typeof value !== "string") return;
      for (const part of value.split(/[;|]/)) {
        const url = imageUrl(part.replaceAll("\\/", "/"));
        if (url && !/avatar|logo|icon|sprite/i.test(url)) images.push(url);
      }
    };
    // Product image arrays take priority over recommendations and page icons.
    for (const payload of payloads) walk(payload, (obj) => {
      for (const key of ["imagePathList", "imageUrlList", "productImageList", "imageURLs", "imageUrls"]) add(obj[key]);
    });
    for (const node of $$('meta[property="og:image"], [class*="slider"] img, [class*="gallery"] img', doc)) {
      add(node.getAttribute("content") || node.getAttribute("data-src") || node.currentSrc || node.getAttribute("src"));
    }
    for (const payload of payloads) walk(payload, (obj) => {
      for (const key of ["image", "imageUrl", "imgUrl", "skuPropertyImagePath", "imagePath"]) add(obj[key]);
    });
    return uniq(images).slice(0, 40);
  }

  function sellerName(doc, payloads) {
    const visible = textFrom(doc, [
      '[class*="store-name"]', '[class*="shop-name"]', '[data-pl="store-name"]',
      'a[href*="/store/"]'
    ]);
    if (visible) return visible.slice(0, 160);
    let found = "";
    for (const payload of payloads) {
      walk(payload, (obj) => {
        if (found) return;
        const value = firstValue(obj, ["storeName", "shopName", "sellerName"]);
        if (value) found = clean(value).slice(0, 160);
      });
      if (found) break;
    }
    return found;
  }

  function productSignalNodes(doc, selector) {
    return $$(selector, doc).filter(node => !node.closest?.('#antc-panel, header, nav, footer, [class*="recommend" i], [class*="related" i], [class*="suggest" i]'));
  }

  function isThriftMartConnection(doc, seller) {
    const signals = [seller];
    for (const node of productSignalNodes(doc, '[class*="store"], [class*="shop"], [data-pl*="store"], a[href*="/store/"], [class*="bundle"], [class*="thrift"], [class*="dollar"]')) {
      signals.push(clean(node.textContent || node.getAttribute("title") || node.getAttribute("aria-label")).slice(0,240));
    }
    return /알뜰\s*마트|Dollar\s*Express|Bundle\s*deals/i.test(signals.join(" | "));
  }

  function detailChoiceConfirmed(doc, payloads) {
    for (const node of productSignalNodes(doc, '[class*="choice" i], [data-pl*="choice" i], img[alt], img[src*="choice" i]')) {
      const alt = clean(node.getAttribute("alt"));
      const signal = [node.className, node.getAttribute("data-pl"), node.getAttribute("src"), node.tagName === "IMG" ? (/^(choice|초이스)$/i.test(alt) ? alt : "") : node.textContent].filter(Boolean).join(" ");
      if (/(?:^|[^a-z])choice(?:[^a-z]|$)|초이스/i.test(signal)) return true;
    }
    let confirmed = false;
    for (const payload of payloads) walk(payload, (obj, path) => {
      if (/recommend|related|suggest|feed|search|header|footer|navigation/i.test(path.join("."))) return;
      for (const key of ["isChoice", "isChoiceProduct", "choiceProduct", "choice"]) {
        if ([true,1,"true","1"].includes(obj[key])) confirmed = true;
      }
    });
    return confirmed;
  }

  function collectionTransportError(error){return /Tabs cannot be edited|user may be dragging a tab|message channel closed|message port closed|Receiving end does not exist|수집 연결이 끊겼습니다/i.test(String(error?.message||error));}
  async function detailMessage(message){
    for(let attempt=0;;attempt++)try{return await chrome.runtime.sendMessage(message);}catch(error){
      if(!collectionTransportError(error)||attempt>=2)throw error;
      await sleep(1000*(attempt+1));
    }
  }
  async function collectDetail(seed, minStock) {
    state.lastExclusion='';state.lastDuplicate=false;
    for(let attempt=0;attempt<3;attempt++){
      const requestId=`${Date.now()}-${Math.random().toString(36).slice(2)}`;
      try{
        const accepted=await detailMessage({type:'ANTC_DETAIL_START',requestId,url:seed.source_url,choiceConfirmed:seed.choice===true,minStock});
        if(!accepted?.ok)throw Object.assign(new Error(accepted?.error||'상세 수집 시작 응답 없음'),{retryable:accepted?.retryable});
        let response;
        while(true){
          await sleep(1000);
          const result=await detailMessage({type:'ANTC_DETAIL_POLL',requestId});
          if(!result?.ok)throw Object.assign(new Error(result?.error||'상세 수집 응답 없음'),{retryable:result?.retryable});
          if(result.done){response=result.response;break;}
        }
        await detailMessage({type:'ANTC_DETAIL_ACK',requestId}).catch(()=>{});
        state.lastDuplicate=Boolean(response?.duplicate);
        if(response?.excluded){state.lastExclusion=response.excluded;return [];}
        if(response?.error)throw Object.assign(new Error(response.error),{retryable:response.retryable,human_verification:response.human_verification});
        if(!response?.rows?.length)throw new Error('상세 옵션을 읽지 못함');
        return response.rows.filter(row=>row.choice===true).map(row=>({...seed,...row}));
      }catch(error){
        if(!(error.retryable||collectionTransportError(error))||attempt>=2)throw error;
        log(`크롬 일시 오류 · 같은 상품 재시도 ${attempt+1}/2`);await sleep(1500*(attempt+1));
      }
    }
  }

  function csvEscape(value) {
    if (Array.isArray(value)) value = value.join(" | ");
    const text = value == null ? "" : String(value);
    return `"${text.replaceAll('"', '""')}"`;
  }

  function timestamp() {
    const d = new Date();
    const pad = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}`;
  }

  function downloadText(filename, text, type) {
    const blob = new Blob([text], { type });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    document.documentElement.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  }

  function exportFiles() {
    if (!state.results.length) {
      setStatus("내보낼 결과가 없어.");
      return;
    }
    const columns = [
      "source_url", "supplier_title", "seller", "choice", "option", "sku_id", "sku_attr", "stock",
      "supplier_price_krw", "main_image", "detail_images", "eligible", "reason"
    ];
    const qualified = state.results.filter((row) => row.eligible);
    const csv = [columns.join(","), ...qualified.map((row) => columns.map((key) => csvEscape(row[key])).join(","))].join("\r\n");
    const stamp = timestamp();
    downloadText(`알리_네일팁_등록가능_${stamp}.csv`, `\uFEFF${csv}`, "text/csv;charset=utf-8");
    downloadText(`알리_네일팁_전체검수_${stamp}.json`, JSON.stringify({
      exported_at: new Date().toISOString(),
      source_page: location.href,
      total_rows: state.results.length,
      eligible_rows: qualified.length,
      rows: state.results,
    }, null, 2), "application/json;charset=utf-8");
    setStatus(`저장 완료\n등록 가능 옵션 ${qualified.length}개 / 전체 ${state.results.length}개`);
  }

  function setStatus(text) {
    const node = $("#antc-status");
    if (node) node.textContent = text + (state.runJob?.stats ? `\n상세 확인 ${state.runJob.stats.examined} · 중복 ${state.runJob.stats.duplicates} · 초이스 미확인 ${state.runJob.stats.choiceUnknown} · 알뜰마트 ${state.runJob.stats.thrift} · 재고 미확인 ${state.runJob.stats.stockUnknown} · 품절 제외 ${state.runJob.stats.soldOut||0} · 실패 ${state.runJob.stats.failed}` : "");
  }

  async function sendToManager() {
    if(state.transferring)return false;
    if (!state.results.length) {
      setStatus("전송할 결과가 없어. 먼저 수집해줘.");
      return;
    }
    state.transferring=true;$("#antc-send").disabled=true;$("#antc-send-restart").disabled=true;
    try {
      const result = await chrome.runtime.sendMessage({ type: "ANTC_SEND_MANAGER", rows: state.results });
      if (!result?.ok) throw new Error(result?.error || "프로그램 응답 없음");
      setStatus(`프로그램 전송 완료\n신규 ${result.inserted} · 갱신 ${result.updated} · 자동작업 ${result.queued || 0}`);
      return true;
    } catch (error) {
      setStatus(`프로그램 연결 실패\n알리 쿠팡 매니저를 먼저 실행해.\n${error.message}`);
      return false;
    } finally {state.transferring=false;$("#antc-send").disabled=!state.results.length;$("#antc-send-restart").disabled=false;}
  }

  function log(text) {
    const node = $("#antc-log");
    if (!node) return;
    node.textContent += `${text}\n`;
    node.scrollTop = node.scrollHeight;
  }

  function setProgress(value, max) {
    const bar = $("#antc-progress");
    if (!bar) return;
    bar.max = Math.max(1, max);
    bar.value = value;
  }

  async function saveCheckpoint() {
    try {
      await chrome.storage.local.set({
        antc_checkpoint: {
          saved_at: new Date().toISOString(),
          source_page: location.href,
          results: state.results,
        },
      });
    } catch { /* export still works without checkpoint */ }
  }

  function applyStockPolicy(rows){return rows.filter(row=>row.stock!==0).map(row=>{const known=typeof row.stock==='number'&&Number.isFinite(row.stock),eligible=row.choice===true&&!row.thrift_mart&&known&&row.stock>0;return {...row,eligible,reason:eligible?'등록 가능':known&&row.stock<=0?'품절':row.reason};});}

  function eligibleProductCount(rows) {
    return new Set(rows.filter(row => row.choice === true && !row.thrift_mart && row.eligible && row.main_image).map(row => row.source_url)).size;
  }

  function bufferedProductCount(rows){return new Set(rows.filter(row=>row.choice===true&&!row.thrift_mart&&row.stock!==0).map(row=>canonicalItemUrl(row.source_url)||row.source_url).filter(Boolean)).size;}
  function batchDue(job){return state.results.length>0&&(bufferedProductCount(state.results)>=50||Date.now()-(job.lastSentAt||job.id)>=5*60*1000);}

  function nextSearchControl(doc = document) {
    const candidates = [...doc.querySelectorAll('a[rel="next"], [class*="pagination-next"], [aria-label], button, a')];
    for (const node of candidates) {
      const label = clean([node.getAttribute("aria-label"), node.getAttribute("title"), node.textContent].filter(Boolean).join(" "));
      const rel = node.getAttribute("rel");
      if (rel !== "next" && !/pagination-next/i.test(String(node.className || "")) && !node.closest('[class*="pagination"], nav[aria-label*="pagination"], nav[aria-label*="Pagination"]')) continue;
      const cls = String(node.className || "");
      if (rel !== "next" && !/pagination-next/i.test(cls) && !/^(?:next(?: page)?|다음(?: 페이지)?|下一页|下一頁)(?:\s|$)/i.test(label)) continue;
      if (node.disabled || node.getAttribute("aria-disabled") === "true" || /disabled/i.test(cls) || node.closest('[aria-disabled="true"], [class*="pagination-disabled"]')) continue;
      const target = node.matches('a,button') ? node : node.querySelector('a,button');
      if (!target || target.disabled || target.getAttribute("aria-disabled") === "true" || target.getClientRects().length === 0) continue;
      const href = target.getAttribute("href");
      if (href && href !== "#") {
        const url = new URL(href, location.href);
        if (!/(^|\.)aliexpress\.com$/i.test(url.hostname) || !/^https:$/.test(url.protocol) || /\/item\//i.test(url.pathname)) continue;
        if (url.href === location.href) continue;
        return { node: target, url: url.href };
      }
      return { node: target, url: null };
    }
    return null;
  }

  function searchSignature(links) {
    return links.map(item => item.source_url).sort().join("|");
  }

  async function persistRun(job) {
    job.results = state.results;
    const response = await chrome.runtime.sendMessage({ type: "ANTC_RUN_STATE", action: "save", job });
    if (!response?.ok) throw new Error("페이지 이동용 수집 기록을 저장하지 못했습니다. 현재 결과를 저장해 주세요.");
  }

  async function run(resumeJob = null) {
    if (state.running) return;
    if (/\/item\//i.test(location.pathname)) { setStatus("상품 상세페이지가 아닌 검색결과에서 시작해 주세요."); return; }
    const job = resumeJob?.id ? resumeJob : {
      id: Date.now(), minStock: 1,
      target: Math.min(200, Math.max(1, Number($("#antc-limit").value) || 200)),
      autoSend: true, sentProducts: 0, seen: [], pages: [], results: [], pageCount: 0,
    };
    job.minStock=1;job.sentProducts ||= 0;job.autoSend=true;
    if(!resumeJob?.id || resumeJob.paused){
      const gate=await chrome.runtime.sendMessage({type:"ANTC_RUN_STATE",action:"acquire",job});
      if(!gate?.ok){setStatus(gate?.error||"다른 작업이 진행 중입니다.");return;}
    }
    job.stats ||= {examined:0,duplicates:0,choiceUnknown:0,thrift:0,stockUnknown:0,failed:0};
    job.paused=false;job.cancelled=false;
    state.runJob = job;
    state.running = true;
    state.stop = false;
    state.results = applyStockPolicy(job.results || []);job.results=state.results;
    $("#antc-panel").hidden = false;
    $("#antc-min-stock").value = job.minStock;
    $("#antc-limit").value = job.target;
    $("#antc-auto-send").checked = job.autoSend;
    $("#antc-log").textContent = "";
    $("#antc-start").disabled = true;
    $("#antc-resume").disabled = true;
    $("#antc-stop").disabled = false;
    $("#antc-export").disabled = true;
    $("#antc-send").disabled = false;
    let navigating = false, endReason = "목표 달성";
    try {
      const seen = new Set(job.seen.map(url => canonicalItemUrl(url) || url));
      if (batchDue(job)) await flushBatch(job);
      while (!state.stop && collectedTotal(job) < job.target) {
        const known=await chrome.runtime.sendMessage({type:'ANTC_KNOWN_PRODUCTS'});
        if(!known?.ok)throw new Error(known?.error||'중복 목록을 받지 못했습니다. 앱을 실행한 뒤 이어하기를 누르세요.');
        for(const id of known.product_ids||[])seen.add(`https://ko.aliexpress.com/item/${id}.html`);
        for(const url of known.urls||[]){const canonical=canonicalItemUrl(url);if(canonical)seen.add(canonical);}
        job.seen=[...seen];
        log(`상세 열기 전 기존 상품번호 대조 · ${known.product_ids?.length??known.urls?.length??0}상품`);
        setStatus(`${job.pageCount + 1}페이지 검색결과 불러오는 중…`);
        await autoScroll();
        let links = scanSearchPage(false), signature = searchSignature(scanSearchPage(false));
        if (job.awaitingNavigation && signature === job.previousSignature) {
          for (let i = 0; i < 20 && !state.stop && signature === job.previousSignature; i++) {
            await sleep(500); links = scanSearchPage(false); signature = searchSignature(scanSearchPage(false));
          }
        }
        job.awaitingNavigation = false;
        const continuing=job.currentPage===signature && (!job.pageComplete||Boolean(job.retrySeeds?.length));
        if (job.pages.includes(signature) && !continuing) { endReason = "같은 검색결과가 반복되어 종료"; break; }
        if(!continuing){job.pages.push(signature);job.pageCount++;}
        job.currentPage=signature;job.pageComplete=false;
        await persistRun(job);
        const retrySeeds=job.retrySeeds||[];
        const candidates=[...new Map([...retrySeeds,...links].map(seed=>[canonicalItemUrl(seed.source_url)||seed.source_url,seed])).values()];
        for (const seed of candidates) {
          if (state.stop || collectedTotal(job) >= job.target) break;
          if (seen.has(canonicalItemUrl(seed.source_url)||seed.source_url)) {job.stats.duplicates++;setStatus(`기존 상품 중복 ${job.stats.duplicates}개 · 상세 열기 생략`);continue;}
          setStatus(`${job.pageCount}페이지 · 등록 가능 상품 ${collectedTotal(job)}/${job.target}개\n${seed.search_title.slice(0,70)}`);
          const detailStarted=Date.now();
          try {
            state.lastDuplicate=false;
            const rows = await collectDetail(seed, job.minStock);
            seen.add(seed.source_url);job.seen=[...seen];
            job.retrySeeds=(job.retrySeeds||[]).filter(item=>item.source_url!==seed.source_url);
            if(state.lastDuplicate){job.stats.duplicates++;await persistRun(job);continue;}
            job.stats.examined++;job.failureStreak=0;
            if (!rows.length) {
              if (/알뜰|최소 주문/.test(state.lastExclusion)) job.stats.thrift++;
              else if (/품절/.test(state.lastExclusion)) job.stats.soldOut=(job.stats.soldOut||0)+1;
              else job.stats.choiceUnknown++;
            } else if (rows.every(row => typeof row.stock !== "number")) job.stats.stockUnknown++;
            state.results.push(...rows);
            log(rows.length ? `상세 완료 ${job.stats.examined}상품 · 이번 ${Math.round((Date.now()-detailStarted)/1000)}초 · 수집 옵션 ${rows.length}개 / 등록 가능 ${rows.filter(row => row.eligible).length}개` : `제외 · ${Math.round((Date.now()-detailStarted)/1000)}초 · ${state.lastExclusion || "초이스 미확인"}`);
          } catch (error) {
            job.stats.failed++;job.failureStreak=(job.failureStreak||0)+1;
            if(!(job.retrySeeds||[]).some(item=>item.source_url===seed.source_url))job.retrySeeds=[...(job.retrySeeds||[]),seed];
            log(`수집 실패 · ${error.message}`);
            await persistRun(job);
            if(error.human_verification)throw error;
            if(error.retryable||collectionTransportError(error))throw new Error('크롬 탭·통신 오류가 계속되어 일시정지했습니다. 실패 상품은 보존되어 이어하기에서 다시 확인합니다.');
          }
          setProgress(collectedTotal(job), job.target);
          await persistRun(job);
          if (batchDue(job) && !state.stop) await flushBatch(job);
          if (job.failureStreak >= 5) throw new Error("상세 확인이 5회 연속 실패했습니다. 페이지 이동을 멈췄습니다. 위 실패 사유를 확인해 주세요.");
          await sleep(400 + Math.floor(Math.random()*400));
        }
        if(!state.stop)job.pageComplete=true;
        await saveCheckpoint();
        const watchlist = [...new Set(state.results.filter(row => row.choice === true && !row.thrift_mart).map(row => row.source_url))].map(source_url => ({source_url,choice:true}));
        await chrome.storage.local.set({antc_watchlist:watchlist});
        if (state.stop || collectedTotal(job) >= job.target) break;
        if (job.pageCount >= 50) { endReason = "최대 50페이지 확인 후 종료"; break; }
        const next = nextSearchControl();
        if (!next) { endReason = "마지막 페이지 · 다음 페이지 없음"; break; }
        job.awaitingNavigation = true; job.previousSignature = signature; job.nextUrl = next.url;
        await persistRun(job);
        setStatus(`${job.pageCount}페이지 완료 · 다음 페이지로 이동 중…`);
        if (next.url) {
          // Persist before a full navigation; the new content script resumes this tab's job.
          navigating = true; location.assign(next.url); return;
        }
        next.node.click();
        await sleep(1500);
        // SPA changes continue here; a full reload resumes from the saved tab session.
      }
      await saveCheckpoint();
      setProgress(collectedTotal(job), job.target);
      setStatus(`${state.stop ? "일시정지 · 이어하기 가능" : "수집 완료 · " + endReason}\n등록 가능 상품 ${collectedTotal(job)}/${job.target}개 · 옵션 ${state.results.length}개 · ${job.pageCount}페이지 확인`);
      $("#antc-export").disabled = !state.results.length;
      $("#antc-send").disabled = !state.results.length;
      if (!state.stop && state.results.length) {
        exportFiles();
        if (job.autoSend) await flushBatch(job);
      }
    } catch (error) {
      job.paused=true;
      setStatus(`수집 중단 · ${error.message}\n현재 결과 ${state.results.length}개는 저장할 수 있습니다.`);
      $("#antc-export").disabled = !state.results.length;
      $("#antc-send").disabled = !state.results.length;
      await saveCheckpoint();
    } finally {
      state.running = false;
      $("#antc-start").disabled = false;
      if (!navigating) {
        $("#antc-stop").disabled=true;
        if(job.paused || state.stop){
          job.paused=true;job.awaitingNavigation=false;state.runJob=job;
          await persistRun(job).catch(()=>{});
          $("#antc-resume").disabled=false;
        }else{
          // Retain the last cursor in memory for a later transfer-and-continue.
          job.paused=true;state.runJob = job;
          await chrome.runtime.sendMessage({type:"ANTC_RUN_STATE",action:"clear"}).catch(()=>{});
        }
        if(state.sendAfterPause){
          state.sendAfterPause=false;
          const continueAfterSend=state.restartAfterSend;
          state.restartAfterSend=false;
          if(continueAfterSend) await handoffAndContinue(job);
          else await sendToManager();
        }
      }
    }
  }

  function collectedTotal(job) {return (job.sentProducts || 0) + eligibleProductCount(state.results);}

  async function flushBatch(job) {
    const count=eligibleProductCount(state.results),collected=bufferedProductCount(state.results);
    if(!await sendToManager()) throw new Error("자동 전송 실패 · 결과 보존 후 일시정지. 프로그램 실행 상태를 확인하고 이어하기를 눌러 주세요.");
    job.sentProducts=(job.sentProducts||0)+count;
    job.sentCollectedProducts=(job.sentCollectedProducts||0)+collected;job.lastSentAt=Date.now();
    state.results=[];job.results=[];
    await saveCheckpoint();await persistRun(job);
    log(`앱 전송 완료 · 이번 ${collected}상품 · 누적 수집 ${job.sentCollectedProducts}상품 / 등록 가능 ${job.sentProducts}상품 · 이어서 수집`);
  }

  async function handoffAndContinue(job) {
    if (!await sendToManager()) return false;
    // Keep the cursor and URL history; only acknowledged results leave the buffer.
    if(job)job.sentProducts=(job.sentProducts||0)+eligibleProductCount(state.results);
    state.results = [];
    await saveCheckpoint();
    if (job?.id) {
      if(job.sentProducts>=job.target)job.target+=Math.min(200,Math.max(1,Number($("#antc-limit").value)||200));
      job.results = [];
      job.pageComplete = false;
      job.paused = true;
      job.pauseRequested = false;
      await persistRun(job);
      state.runJob = job;
      await run(job);
    } else {
      await run();
    }
    return true;
  }

  function pauseCollection(send=false,restart=false){
    if(!state.running){
      if(send){if(restart) handoffAndContinue(state.runJob);else sendToManager();}
      return;
    }
    state.stop=true;state.sendAfterPause=send;state.restartAfterSend=restart;
    if(state.runJob){state.runJob.pauseRequested=true;persistRun(state.runJob).catch(()=>{});}
    setStatus(send?"현재 상품 처리 후 일시정지하고 앱으로 전송할게…":"현재 상품 처리 후 일시정지할게 · 결과는 유지됩니다.");
  }
  async function continueCollection(){
    if(state.running||state.transferring)return;
    const response=await chrome.runtime.sendMessage({type:"ANTC_RUN_STATE",action:"get"});
    const job=state.runJob||response?.job;
    if(!job?.paused)return setStatus("이어갈 수집 기록이 없어. 새로 수집을 시작해줘.");
    await run(job);
  }

  async function resumeRun() {
    try {
      const response = await chrome.runtime.sendMessage({type:"ANTC_RUN_STATE",action:"get"});
      const job = response?.job;
      if(job?.paused){
        state.runJob=job;job.minStock=1;job.sentProducts ||= 0;job.autoSend=true;state.results=applyStockPolicy(job.results||[]);job.results=state.results;
        $("#antc-min-stock").value=job.minStock;$("#antc-limit").value=job.target;$("#antc-auto-send").checked=job.autoSend;
        setProgress(eligibleProductCount(state.results),job.target);
        $("#antc-panel").hidden=false;$("#antc-resume").disabled=false;
        $("#antc-export").disabled=!state.results.length;$("#antc-send").disabled=!state.results.length;
        setStatus(`일시정지한 수집 ${state.results.length}옵션 복원 · 이어하기 또는 앱으로 전송 가능`);return;
      }
      if (!job?.awaitingNavigation || job.cancelled || /\/item\//i.test(location.pathname)) return;
      if (job.nextUrl && new URL(job.nextUrl).href !== location.href) {
        setStatus("예정된 다음 페이지와 주소가 달라 자동 수집을 멈췄습니다.");
        return;
      }
      await run(job);
    } catch { /* A manually opened page needs no automatic action. */ }
  }

  async function clearAll() {
    if(state.running)return setStatus("먼저 일시정지한 뒤 기록을 비워줘.");
    state.runJob=null;$("#antc-resume").disabled=true;
    state.results = [];
    state.links = [];
    state.stop = true;
    await chrome.runtime.sendMessage({type:"ANTC_RUN_STATE",action:"clear"}).catch(()=>{});
    $("#antc-log").textContent = "";
    setProgress(0, 1);
    setStatus("수집 기록을 비웠어.");
    $("#antc-export").disabled = true;
    $("#antc-send").disabled = true;
    try { await chrome.storage.local.remove("antc_checkpoint"); } catch { /* ignore */ }
  }

  function injectUI() {
    const launcher = document.createElement("button");
    launcher.id = "antc-launcher";
    launcher.type = "button";
    launcher.textContent = "💅 네일팁 수집";

    const panel = document.createElement("section");
    panel.id = "antc-panel";
    panel.hidden = true;
    panel.innerHTML = `
      <h2>알리 네일팁 수집기</h2>
      <p>수집을 시작하면 이 알리 탭을 수집 전용 창으로 옮깁니다. 다른 창에서 인터넷을 사용해도 됩니다. 초이스만 수집하며 알뜰마트는 제외합니다.</p>
      <label class="antc-check"><input id="antc-choice-only" type="checkbox" checked disabled> 초이스 확인 상품만</label>
      <label class="antc-check"><input id="antc-auto-send" type="checkbox" checked disabled> 50상품 또는 5분마다 앱 전송 · 남은 상품은 완료 시 전송</label>
      <input id="antc-min-stock" type="hidden" value="1">
      <p>최소 재고 제한 없음 · 품절과 재고 미확인 옵션만 제외</p>
      <label for="antc-limit">등록 가능 상품 목표 수 (옵션 수 아님)</label>
      <input id="antc-limit" type="number" min="1" max="200" value="200">
      <progress id="antc-progress" value="0" max="1"></progress>
      <div id="antc-status">검색 결과 페이지에서 수집 시작을 눌러.</div>
      <div id="antc-log"></div>
      <div class="antc-actions">
        <button id="antc-start" type="button">새로 수집</button>
        <button id="antc-resume" type="button" disabled>이어하기</button>
        <button id="antc-stop" type="button" disabled>일시정지</button>
        <button id="antc-send-restart" type="button">앱 전송 후 계속 수집</button>
        <button id="antc-export" type="button" disabled>결과 저장</button>
        <button id="antc-send" type="button">현재까지 앱 전송</button>
        <button id="antc-clear" type="button">기록 비우기</button>
        <button id="antc-close" type="button">닫기</button>
      </div>`;

    document.documentElement.append(launcher, panel);
    launcher.addEventListener("click", () => { panel.hidden = !panel.hidden; });
    $("#antc-close").addEventListener("click", () => { panel.hidden = true; });
    $("#antc-start").addEventListener("click", () => run());
    $("#antc-stop").addEventListener("click", () => pauseCollection());
    $("#antc-resume").addEventListener("click", continueCollection);
    $("#antc-send-restart").addEventListener("click", () => pauseCollection(true,true));
    $("#antc-export").addEventListener("click", exportFiles);
    $("#antc-send").addEventListener("click", () => pauseCollection(true));
    $("#antc-clear").addEventListener("click", clearAll);
  }

  injectUI();
  const humanButton=document.createElement("button");humanButton.textContent="사람 확인 후 재개";humanButton.style.cssText="margin:8px 0;width:100%";humanButton.onclick=async()=>{try{if(window.ANTC_HUMAN_VERIFICATION?.required(document,location.href)){setStatus("체크박스·드래그 확인이 아직 표시됩니다. 직접 확인을 마친 뒤 재개해주세요.");return;}const result=await chrome.runtime.sendMessage({type:"ANTC_HUMAN_RESUME"});if(result?.ok){setStatus("사람 확인 대기 해제 · 일시정지한 수집은 이어하기를 눌러 주세요. 앱 재고 확인은 진행 중인 재시도에서 이어집니다.");}else setStatus(result?.error||"재개 실패");}catch(error){setStatus(error.message)}};$("#antc-panel").append(humanButton);
  resumeRun();
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if(message?.type==="ANTC_COLLECTION_PROGRESS" && state.running){setStatus(message.text);}
    if (message?.type === "ANTC_OPEN") {
      const panel = $("#antc-panel");
      if (panel) panel.hidden = false;
    }
    if (message?.type === "ANTC_COLLECT_CURRENT") {
      (async () => {
        try {
          const checkHuman=()=>Boolean(window.ANTC_HUMAN_VERIFICATION?.required(document,location.href));
          if(checkHuman()){sendResponse({rows:[],human_verification:true,error:"사람 확인 필요 · 수집 전용 창에서 직접 해제하고 사람 확인 후 재개를 눌러 주세요."});return;}
          const pageText = clean(document.body?.innerText || "");
          if (/상품을 찾을 수 없|더 이상 판매|페이지를 찾을 수 없|not found|no longer available/i.test(textFrom(document,["h1","title"])) || (pageText.length < 2000 && !document.querySelector('[class*="product-title"], [class*="sku-item"]') && /상품을 찾을 수 없|더 이상 판매|페이지를 찾을 수 없|no longer available/i.test(pageText))) {
            sendResponse({ rows: [{ source_url: canonicalItemUrl(location.href) || location.href, choice: message.choiceConfirmed === true, discontinued: true, reason: "단종 또는 판매 종료" }] });
            return;
          }
          for (let attempt = 0; attempt < 10; attempt += 1) {
            if (document.querySelector('h1, meta[property="og:title"], script[type="application/json"]')) break;
            await sleep(500);
          }
          await sleep(1000);
          if(checkHuman())throw Object.assign(new Error("사람 확인 필요 · 수집 전용 창에서 직접 해제하고 사람 확인 후 재개를 눌러 주세요."),{human_verification:true});
          const payloads = jsonPayloads(document, Array.isArray(message.pagePayloads) ? message.pagePayloads : []);
          const title = textFrom(document, ['meta[property="og:title"]', "h1", "title"]);
          const seller = sellerName(document, payloads);
          const thriftMart = isThriftMartConnection(document, seller);
          const confirmedChoice = detailChoiceConfirmed(document, payloads);
          if (thriftMart && message.collectionMode !== "existing") {
            sendResponse({ rows: [], excluded: "알뜰마트 · 최소 주문 상품 수집 제외" });
            return;
          }
          if (!confirmedChoice && message.collectionMode === "new") {
            sendResponse({rows:[],choice_unconfirmed:true,error:"상세페이지 초이스 표시 미확인"});
            return;
          }
          const images = detailImages(document, payloads);
          let rows = skuRows(payloads);
          let optionScan={scanned:false,message:""};
          if(message.mode!=="images" && window.ANTC_OPTION_INVENTORY){
            optionScan=await window.ANTC_OPTION_INVENTORY.collect({doc:document,wait:sleep,checkHuman,payloadRows:rows,targetOptions:Array.isArray(message.targetOptions)?message.targetOptions:null,onProgress:progress=>{
              if(message.progressTabId)chrome.runtime.sendMessage({type:"ANTC_DETAIL_PROGRESS",tabId:message.progressTabId,text:`옵션 확인 ${progress.completed}/${progress.total} · ${progress.option} · ${progress.stock===null?progress.reason:'재고 '+progress.stock+'개'}`}).catch(()=>{});
            }});
            rows=optionScan.rows.map(row=>({...row,main_image:imageUrl(row.main_image)}));
          }
          const source = canonicalItemUrl(location.href) || location.href;
          const minStock = 1;
          const diagnostic = { payloads: payloads.length, sku_rows: rows.length, collector_version: chrome.runtime.getManifest().version, option_scan:optionScan.message };
          const normalized = rows.length ? rows.map((row) => {
            const known = typeof row.stock === "number";
            const eligible = confirmedChoice && !thriftMart && known && row.stock >= minStock;
            const reason = !confirmedChoice ? "초이스 미확인" : thriftMart ? "알뜰마트 연결" : !known ? row.stock_reason || `재고 미확인 · 상품 데이터 ${payloads.length}개 / 옵션 ${rows.length}개` : row.stock < minStock ? "품절" : "등록 가능";
            return { source_url: source, supplier_title: title, seller, thrift_mart: thriftMart, choice: confirmedChoice, option: row.option, sku_id: row.sku_id, sku_attr: row.sku_attr, stock: row.stock, supplier_price_krw: row.price_krw, price_source:row.price_source||"payload_sku", price_reason:row.price_reason||"", stock_reason:row.stock_reason||"", main_image: row.main_image || images[0] || "", detail_images: images, eligible, reason, collection_debug: {...diagnostic,stock_source:row.stock_source||"payload",sku_id_source:row.sku_id_source||"payload"} };
          }) : [{ source_url: source, supplier_title: title, seller, thrift_mart: thriftMart, choice: confirmedChoice, stock: null, main_image: images[0] || "", detail_images: images, eligible: false, reason: thriftMart ? "알뜰마트 연결" : `옵션·재고 수집 실패 · 상품 데이터 ${payloads.length}개 / 옵션 0개`, collection_debug: diagnostic }];
          const collected=message.collectionMode==='new'?normalized.filter(row=>row.stock!==0):normalized;
          sendResponse({ rows: collected,...(message.collectionMode==='new'&&normalized.length&&!collected.length?{excluded:'모든 옵션 품절 · 수집 제외'}:{}),option_scan_complete:optionScan.scanned,option_scan_message:optionScan.message });
        } catch (error) { sendResponse({ error: error.message, rows: [],human_verification:Boolean(error.human_verification) }); }
      })();
      return true;
    }
  });
})();
