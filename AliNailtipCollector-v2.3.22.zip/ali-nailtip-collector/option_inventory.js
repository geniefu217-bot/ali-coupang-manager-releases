(() => {
  'use strict';
  if (window.ANTC_OPTION_INVENTORY) return;
  const clean=v=>String(v??'').replace(/\s+/g,' ').trim();
  const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
  const GROUP='[class*="sku-item--property--"], .sku-property, [data-sku-property]';
  const VALUE='[class*="sku-item--image--"], [class*="sku-item--text--"], .sku-property-item, [data-sku-value]';
  const HEADER='[class*="sku-item--title--"], .sku-title, [data-sku-selected-value]';
  function purchaseLimit(text) {
    const s=clean(text);
    const m=s.match(/(?:고객|구매자|회원|계정|1인)\s*(?:1인\s*)?(?:당|별)?\s*(?:구매\s*)?(?:최대|한도|제한)\s*[:：]?\s*([\d,]+)\s*개?|(?:최대|한도)\s*([\d,]+)\s*(?:개\s*)?(?:per\s*(?:customer|buyer)|\/\s*(?:고객|1인))|(?:max(?:imum)?|limit(?:ed)?\s*(?:to)?)\s*[:：]?\s*([\d,]+)\s*(?:items?|pieces?)?\s*(?:per\s*(?:customer|buyer|account))/i);
    if(m&&/^\s*[%％]/.test(s.slice(m.index+m[0].length)))return null;
    const n=m?Number((m[1]||m[2]||m[3]).replaceAll(',','')):null;
    return Number.isSafeInteger(n)&&n>0?n:null;
  }
  function stockNumber(text) {
    const s=clean(text);
    const m=s.match(/(?:재고\s*(?:수량)?|剩余|库存|stock(?:\s*(?:quantity|available))?|available\s*quantity)\s*[:：]?\s*([\d,]+)|([\d,]+)\s*(?:개\s*(?:남|재고|사용\s*가능|이용\s*가능|구매\s*가능)|pieces?\s*(?:available|left)|available\b|items?\s*left|left\b|件可用|件剩余)/i);
    return m?Number((m[1]||m[2]).replaceAll(',','')):purchaseLimit(s);
  }
  const OUTSIDE='#antc-panel,header,nav,footer,[class*="recommend" i],[class*="related" i]';
  const visible=n=>!n.closest?.(OUTSIDE)&&(!n.getClientRects||n.getClientRects().length>0);
  function soldOut(text){return /^(?:품절|일시\s*품절|재고\s*없음|sold\s*out|out\s*of\s*stock|售罄|已售罄|缺货)[.!。]?$/i.test(clean(text));}
  function priceView(doc){
    const selector='[class*="price--current"], [class*="product-price-current"], [class*="uniform-banner-box-price"], [class*="price" i]';
    const candidates=[];
    for(const node of doc.querySelectorAll(selector)){
      if(!visible(node)||node.closest?.('del,s,[class*="original" i],[class*="price--old" i],[class*="price--origin" i],[class*="unit-price" i],[class*="price-per" i],[class*="coupon" i]'))continue;
      const cls=String(node.className||'');
      if(/original|originprice|oldprice|price[-_]*(?:old|origin)|unit[-_]?price|price[-_]?per|coupon|installment|shipping/i.test(cls))continue;
      const text=clean(node.innerText||node.textContent);
      if(text.length>100||/(?:\/|每)\s*(?:개|件|pcs?|piece|세트)|\bper\s+(?:piece|item)|쿠폰|coupon|배송비|shipping/i.test(text))continue;
      const style=typeof getComputedStyle==='function'?getComputedStyle(node):null;
      if(style?.textDecorationLine?.includes('line-through'))continue;
      const matches=[...text.matchAll(/(?:₩|￦|KRW)\s*([\d,]+(?:\.\d+)?)|([\d,]+(?:\.\d+)?)\s*원/gi)];
      const amounts=[...new Set(matches.map(m=>Number((m[1]||m[2]).replaceAll(',',''))).filter(n=>Number.isFinite(n)&&n>0))];
      if(amounts.length!==1)continue;
      const current=/current|sale|final|uniform-banner-box-price/i.test(cls);
      candidates.push({node,price:amounts[0],score:current?0:1,length:text.length,text});
    }
    candidates.sort((a,b)=>a.score-b.score||a.length-b.length);
    if(!candidates.length)return {node:null,price:null,text:''};
    const best=candidates.filter(x=>x.score===candidates[0].score);
    if(new Set(best.map(x=>x.price)).size>1)return {node:null,price:null,text:''};
    return best[0];
  }
  function stockView(doc) {
    const ignored=`${OUTSIDE},${GROUP},[class*="review" i],[class*="description" i],[class*="detail-desc" i]`;
    const usable=n=>visible(n)&&!n.closest?.(ignored);
    const roots=[...doc.querySelectorAll('[class*="quantity" i], [class*="inventory" i], [class*="stock" i], [class*="available" i], [data-pl*="quantity" i], [class*="buy" i], [class*="trade" i], [class*="action" i]')].filter(usable);
    // AliExpress also renders this section with opaque class names. Anchor the
    // fallback to its visible quantity heading, never to page-wide body text.
    const needHeading=!roots.some(n=>{const text=clean(n.innerText||n.textContent);return stockNumber(text)!==null||soldOut(text);});
    for(const heading of needHeading?doc.querySelectorAll('h2,h3,h4,label,span,div,p,strong'):[]){
      if(!usable(heading)||!/^(?:수량|quantity)\s*[:：]?$/i.test(clean(heading.innerText||heading.textContent)))continue;
      let root=heading.parentElement;
      for(let depth=0;root&&depth<3;depth++,root=root.parentElement){
        const text=clean(root.innerText||root.textContent);
        if(text.length>600)break;
        if(usable(root)&&(purchaseLimit(text)!==null||/품절|재고\s*없음|sold\s*out|out\s*of\s*stock/i.test(text))){roots.push(root);break;}
      }
    }
    const nodes=new Set();
    for(const root of roots){nodes.add(root);const text=clean(root.innerText||root.textContent);if(text.length<240&&((stockNumber(text)!==null&&purchaseLimit(text)===null&&!/품절|sold\s*out|out\s*of\s*stock/i.test(text))||soldOut(text)))continue;for(const child of (root.querySelectorAll?.('span,div,p,button,label,strong,em,b,small')||[]))if(usable(child))nodes.add(child);}
    const readings=[...nodes].filter(usable).map(node=>({node,text:clean(node.innerText||node.textContent)})).filter(x=>x.text&&x.text.length<240);
    const sold=readings.find(x=>soldOut(x.text));
    if(sold)return {...sold,stock:0,kind:'sold_out'};
    const inventory=readings.filter(x=>stockNumber(x.text)!==null&&purchaseLimit(x.text)===null).sort((a,b)=>a.text.length-b.text.length);
    const limits=readings.filter(x=>purchaseLimit(x.text)!==null).sort((a,b)=>a.text.length-b.text.length);
    const actual=inventory[0],limit=limits[0];
    if(actual)return {...actual,stock:limit?Math.min(stockNumber(actual.text),purchaseLimit(limit.text)):stockNumber(actual.text),kind:'inventory'};
    if(limit)return {...limit,stock:purchaseLimit(limit.text),kind:'purchase_limit'};
    return {node:null,text:'',stock:null,kind:'unknown'};
  }
  function zeroQuantity(node) {
    for(let root=node?.parentElement,depth=0;root&&depth<3;root=root.parentElement,depth++){
      if(clean(root.innerText||root.textContent).length>600)break;
      if(![...root.querySelectorAll('h2,h3,h4,label,span,div,p,strong')].some(n=>visible(n)&&/^(?:수량|quantity)\s*[:：]?$/i.test(clean(n.innerText||n.textContent))))continue;
      return [...root.querySelectorAll('input,[role="spinbutton"],span,div,p,strong')].some(n=>visible(n)&&clean(n.value??n.getAttribute('aria-valuenow')??n.innerText??n.textContent)==='0');
    }
    return false;
  }
  function groups(doc) {
    return [...doc.querySelectorAll(GROUP)].filter(n=>!n.closest('#antc-panel,[class*="recommend" i],[class*="related" i]')).map((node,index)=>{
      const raw=[...node.querySelectorAll(VALUE)];
      const valueSet=new Set(raw);
      const values=raw.filter(n=>{for(let parent=n.parentElement;parent&&parent!==node;parent=parent.parentElement)if(valueSet.has(parent))return false;return true;}).map((el,i)=>{
        const img=el.querySelector('img');
        const label=clean(el.getAttribute('title')||el.getAttribute('aria-label')||img?.getAttribute('alt')||img?.getAttribute('title')||el.textContent);
        let id=el.getAttribute('data-sku-value')||el.getAttribute('data-sku-id')||'';
        const property=node.getAttribute?.('data-sku-property')||node.getAttribute?.('data-sku-col')||'';
        if(/^\d+$/.test(property)&&/^\d+$/.test(id))id=property+':'+id;
        return {index:i,label:label||id||`옵션 ${i+1}`,id,image:img?.currentSrc||img?.src||'',node:el};
      });
      const heading=clean(node.querySelector(HEADER)?.textContent||'');
      return {index,node,name:heading.split(/[:：]/)[0]||`옵션 ${index+1}`,values};
    }).filter(g=>g.values.length).map((g,index)=>({...g,index}));
  }
  function selected(group,value) {
    const n=value.node;
    if(n.getAttribute('aria-selected')==='true'||n.getAttribute('aria-checked')==='true'||n.getAttribute('data-selected')==='true'||/(?:^|[\s_-])selected(?:[\s_-]|$)/i.test(String(n.className||'')))return true;
    const heading=clean(group.node.querySelector(HEADER)?.textContent||'');
    const chosen=heading.split(/[:：]/).slice(1).join(':').trim();
    return Boolean(chosen&&chosen===value.label);
  }
  function disabled(value) {return value.node.disabled||value.node.getAttribute('aria-disabled')==='true'||/(?:^|[\s_-])disabled(?:[\s_-]|$)/i.test(String(value.node.className||''));}
  function combinations(list,limit=200) {
    let out=[[]];
    for(const group of list){const next=[];for(const row of out)for(const value of group.values){if(next.length>=limit)break;next.push([...row,{group:group.index,label:value.label,id:value.id,index:value.index,name:group.name,image:value.image}]);}out=next;}
    return out;
  }
  function mappedRow(rows,tuple) {
    const matches=rows.filter(row=>{
      const tokens=String(row.sku_attr||'').split(/[;,|]/).filter(Boolean);
      if(tokens.length&&tuple.every(v=>v.id&&tokens.some(t=>t.split('#')[0]===v.id||t.split('#')[0].split(':').pop()===v.id)))return true;
      const parts=String(row.option||'').split(' / ').map(p=>clean(p.split(':').slice(1).join(':')||p));
      return parts.length===tuple.length&&tuple.every(v=>parts.includes(v.label));
    });
    return matches.length===1?matches[0]:undefined;
  }
  function internalKey(tuple){let h=2166136261;for(const c of tuple.map(v=>`${v.name}:${v.id||v.label}`).join('|')){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}return `dom:${(h>>>0).toString(16)}`;}
  function attrKey(value){return String(value||'').split(/[;,|]/).map(t=>t.split('#')[0].trim()).filter(Boolean).sort().join(';');}
  function optionKey(value){return clean(value).split(' / ').map(p=>clean(p.split(/[:：]/).slice(1).join(':')||p).toLowerCase()).sort().join('|');}
  function requestedTuples(initial,payloadRows,targets){
    const all=combinations(initial,10000),chosen=[],missing=[],associations=[],chosenKeys=new Set();
    const byAttr=new Map(),byInternal=new Map(),byOption=new Map();let bySku=null;
    const add=(index,key,tuple)=>{if(key){if(!index.has(key))index.set(key,[]);index.get(key).push(tuple);}};
    for(const tuple of all){add(byAttr,attrKey(tuple.map(v=>v.id).join(';')),tuple);add(byInternal,internalKey(tuple),tuple);add(byOption,optionKey(tuple.map(v=>v.label).join(' / ')),tuple);}
    for(const target of targets){let matches=[];const key=attrKey(target.sku_attr);
      if(key)matches=byAttr.get(key)||[];
      if(!matches.length&&target.sku_id){
        if(!bySku){bySku=new Map();for(const tuple of all){const sku=mappedRow(payloadRows,tuple)?.sku_id;if(sku)add(bySku,String(sku),tuple);}}
        matches=[...new Set([...(byInternal.get(String(target.sku_id))||[]),...(bySku.get(String(target.sku_id))||[])])];
      }
      if(!matches.length&&target.option_name)matches=byOption.get(optionKey(target.option_name))||[];
      if(matches.length===1){const tupleKey=internalKey(matches[0]);associations.push({target,key:tupleKey});if(!chosenKeys.has(tupleKey)){chosenKeys.add(tupleKey);chosen.push(matches[0]);}}
      else missing.push({sku_id:target.sku_id,sku_attr:target.sku_attr,option:target.option_name,stock:null,price_krw:'',price_source:'unknown',stock_source:'unknown',stock_reason:matches.length?'대상 옵션 연결 중복 · 재확인 필요':'요청 옵션을 상세페이지에서 찾지 못함'});
    }
    return {chosen,missing,associations};
  }
  async function collect({doc=document,payloadRows=[],onProgress=()=>{},wait=sleep,clock=()=>Date.now(),timeoutMs=120000,targetOptions=null,checkHuman=()=>false}) {
    const ensureHuman=()=>{if(checkHuman())throw Object.assign(new Error('사람 확인 필요 · 수집 전용 창에서 직접 확인 후 이어하기를 눌러 주세요.'),{human_verification:true});};
    ensureHuman();
    const initial=groups(doc);
    if(!initial.length)return {rows:targetOptions?targetOptions.map(t=>({sku_id:t.sku_id,sku_attr:t.sku_attr,option:t.option_name,stock:null,price_krw:'',stock_reason:'옵션 선택 영역 미인식',price_source:'unknown'})):payloadRows,scanned:false,message:'옵션 선택 영역 미인식'};
    const requested=Array.isArray(targetOptions)?requestedTuples(initial,payloadRows,targetOptions):null;const planned=requested?requested.chosen:combinations(initial),possible=requested?targetOptions.length:initial.reduce((n,g)=>n*g.values.length,1);
    const result=[],started=clock();
    for(let i=0;i<planned.length;i++){
      ensureHuman();
      const tuple=planned[i],mapped=mappedRow(payloadRows,tuple);
      let reason='',stock=null,stockSource='unknown',selectionConfirmed=false;
      if(clock()-started>=timeoutMs)reason='옵션 확인 시간 초과';
      else{
        const before=stockView(doc),beforePrice=priceView(doc);
        let changed=false,mutated=false,observer;
        if(before.node&&typeof MutationObserver!=='undefined'){
          observer=new MutationObserver(()=>{mutated=true;});
          observer.observe(before.node,{childList:true,subtree:true,characterData:true});
        }
        try{
          for(const wanted of tuple){
            const g=groups(doc)[wanted.group];
            const v=g?.values.find(x=>wanted.id&&x.id===wanted.id)||g?.values.find(x=>x.label===wanted.label);
            if(!v||disabled(v)){
              if(v&&(/sold[-_ ]?out|out[-_ ]?of[-_ ]?stock/i.test(String(v.node.className||''))||soldOut(v.node.getAttribute('aria-label')||v.node.getAttribute('title')||''))&&tuple.length===1){stock=0;stockSource='option_sold_out';selectionConfirmed=selected(g,v);}
              else reason='옵션 선택 불가 · 재고 미확인';break;
            }
            if(!selected(g,v)){v.node.click();changed=true;await wait(200);}
          }
          if(!reason&&stock===null){
            await wait(200);
            let stable='',count=0;
            for(let attempt=0;attempt<12;attempt++){
              if(clock()-started>=timeoutMs){reason='옵션 확인 시간 초과';break;}
              ensureHuman();
              const active=groups(doc);
              const confirmed=tuple.every(w=>{const g=active[w.group];const v=g?.values.find(x=>w.id&&x.id===w.id)||g?.values.find(x=>x.label===w.label);return v&&selected(g,v);});
              const current=stockView(doc);
              if(!confirmed){await wait(200);continue;}
              selectionConfirmed=true;
              if(current.stock!==null){
                if(current.text===stable)count++;else{stable=current.text;count=0;}
                // Do not copy an unchanged stock label from the previous option.
                let refreshed=!changed||current.text!==before.text||current.node!==before.node||mutated;
                if(!refreshed&&attempt>=4&&beforePrice.price!==null){const currentPrice=priceView(doc);refreshed=currentPrice.price!==null&&currentPrice.price!==beforePrice.price;}
                // A per-customer cap can legitimately stay identical across SKUs.
                // Wait for the confirmed selection to settle before accepting it.
                const repeatable=current.kind==='purchase_limit'||(current.kind==='sold_out'&&zeroQuantity(current.node));
                if(count>=2&&(refreshed||(repeatable&&attempt>=4))){stock=current.stock;stockSource=current.kind==='purchase_limit'?'selected_option_purchase_limit':current.kind==='sold_out'?'selected_option_sold_out':'selected_option_dom';break;}
              }
              const tokens=String(mapped?.sku_attr||'').split(/[;,|]/).map(t=>t.split('#')[0].trim()).filter(Boolean);
              const exact=tuple.length===tokens.length&&tuple.every(w=>/^\d+:\d+$/.test(w.id)&&tokens.includes(w.id));
              if(current.kind!=='purchase_limit'&&current.kind!=='sold_out'&&attempt>=2&&exact&&typeof mapped?.stock==='number'&&Number.isFinite(mapped.stock)&&mapped.stock>=0){stock=mapped.stock;stockSource='payload_sku';break;}

              await wait(200);
            }
            // Fresh page payload fallback requires all exact property:value pairs and a confirmed selection.
            const exactTokens=String(mapped?.sku_attr||'').split(/[;,|]/).map(t=>t.split('#')[0].trim()).filter(Boolean);
            const exact=tuple.length===exactTokens.length&&tuple.every(w=>/^\d+:\d+$/.test(w.id)&&exactTokens.includes(w.id));
            const active=groups(doc),confirmed=tuple.every(w=>{const g=active[w.group],v=g?.values.find(x=>x.id===w.id)||g?.values.find(x=>x.label===w.label);return v&&selected(g,v);});
            if(stock===null&&!reason&&exact&&confirmed&&(!['purchase_limit','sold_out'].includes(stockView(doc).kind))&&typeof mapped?.stock==='number'&&Number.isFinite(mapped.stock)&&mapped.stock>=0){stock=mapped.stock;stockSource='payload_sku';}
            selectionConfirmed=confirmed;
            if(stock===null)reason=reason||(confirmed?'옵션 선택 후 재고 표시 갱신 미확인':'선택 옵션 확인 실패');
          }
        }finally{observer?.disconnect();}
      }
      const option=tuple.map(v=>`${v.name}: ${v.label}`).join(' / ');
      // Price is independent of inventory; only a confirmed selected tuple may supply it.
      const displayed=selectionConfirmed?priceView(doc):{price:null};
      const tokens=String(mapped?.sku_attr||'').split(/[;,|]/).map(t=>t.split('#')[0].trim()).filter(Boolean);
      const exact=tuple.length===tokens.length&&tuple.every(w=>/^\d+:\d+$/.test(w.id)&&tokens.includes(w.id));
      const payloadPrice=exact&&Number.isFinite(Number(mapped?.price_krw))&&Number(mapped.price_krw)>0?Number(mapped.price_krw):null;
      const priceSource=selectionConfirmed?(displayed.price!==null?'selected_option_dom':payloadPrice!==null?'payload_sku':'unknown'):'unknown';
      result.push({...mapped,option_key:internalKey(tuple),sku_id:mapped?.sku_id||internalKey(tuple),sku_attr:mapped?.sku_attr||tuple.filter(v=>/^\d+:\d+$/.test(v.id)).map(v=>v.id).join(';'),option,stock,price_krw:priceSource==='unknown'?'':displayed.price??payloadPrice,price_source:priceSource,main_image:tuple.find(v=>v.image)?.image||mapped?.main_image||'',price_reason:!selectionConfirmed?'선택 옵션 확인 전 가격 반영 보류':priceSource==='unknown'?'선택 옵션 가격 표시 미인식':'',stock_reason:reason,stock_source:stockSource,sku_id_source:mapped?.sku_id?'payload':'internal_option_key'});
      onProgress({completed:i+1,total:planned.length,option,stock,reason});
    }
    const unmapped=requested?requested.missing:payloadRows.filter(row=>!result.some(item=>item.sku_id===row.sku_id));
    const confirmedRows=requested?requested.associations.map(({target,key})=>{const row=result.find(r=>r.option_key===key);return {...row,actual_sku_id:row.sku_id,sku_id:target.sku_id||row.sku_id,sku_attr:target.sku_attr||row.sku_attr};}):result;
    return {rows:[...confirmedRows,...unmapped],scanned:true,message:possible>planned.length?`옵션 ${possible}개 중 ${planned.length}개 확인 · 나머지 미확인`:`옵션 ${result.length}개 선택 확인`};
  }
  window.ANTC_OPTION_INVENTORY={collect,stockNumber,purchaseLimit,stockView,priceView,groups,combinations,mappedRow};
})();
