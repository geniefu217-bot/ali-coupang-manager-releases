async function openCollector(tab) {
  try {
    await chrome.tabs.sendMessage(tab.id, { type: "ANTC_OPEN" });
  } catch {
    await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ["styles.css"] });
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["verification.js", "option_inventory.js", "content.js"] });
    await chrome.tabs.sendMessage(tab.id, { type: "ANTC_OPEN" });
  }
}

document.querySelector("#open").addEventListener("click", async () => {
  const message = document.querySelector("#message");
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url?.includes("aliexpress.com")) {
      message.textContent = "알리익스프레스 검색 페이지에서 눌러주세요.";
      return;
    }
    await openCollector(tab);
    window.close();
  } catch {
    message.textContent = "알리 페이지를 새로고침한 뒤 다시 눌러주세요.";
  }
});
