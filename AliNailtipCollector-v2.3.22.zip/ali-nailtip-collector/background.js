const MANAGER = "http://127.0.0.1:8765/api/import";

let knownProductIds=null;
function aliItemId(raw){try{const u=new URL(raw);if(!/(^|\.)aliexpress\.(com|us)$/i.test(u.hostname))return '';return u.pathname.match(/\/item\/(\d{8,})(?:\.html|\/|$)/i)?.[1]||u.searchParams.get('productId')?.match(/^\d{8,}$/)?.[0]||'';}catch{return '';}}
async function loadKnownProducts(){
 const response=await fetch('http://127.0.0.1:8765/api/products/known');
 if(!response.ok)throw new Error(`중복 목록 조회 실패 HTTP ${response.status} · 앱 업데이트와 실행 상태를 확인하세요.`);
 const data=await response.json();
 if(!data.ok||!Array.isArray(data.product_ids))throw new Error('전체 중복 목록을 받지 못했습니다. 앱을 업데이트해 주세요.');
 knownProductIds=new Set(data.product_ids.map(String));
 return {ok:true,product_ids:[...knownProductIds]};
}

const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
// Timers run in the extension worker so hidden product pages do not stretch the intended stable-read waits.
chrome.runtime.onMessage.addListener((message,sender,sendResponse)=>{
 if(message?.type!=='ANTC_DELAY')return false;
 const ms=message.ms;
 if(!sender.tab?.id||typeof ms!=='number'||!Number.isFinite(ms)||ms<0||ms>5000){sendResponse({ok:false,error:'잘못된 대기 요청'});return false;}
 setTimeout(()=>sendResponse({ok:true}),ms);return true;
});

function transientTabError(error){return /Tabs cannot be edited|user may be dragging a tab|message channel closed|message port closed|Receiving end does not exist|수집 연결이 끊겼습니다/i.test(String(error?.message||error));}
async function retryTabOperation(operation){
 for(let attempt=0;;attempt++)try{return await operation();}catch(error){
  if(!/Tabs cannot be edited|user may be dragging a tab/i.test(error.message)||attempt>=11)throw error;
  await delay(Math.min(2000,500+attempt*250));
 }
}
let collectorWindowId=null;
async function ensureCollectorWindow(searchTabId=null){
 if(collectorWindowId==null)collectorWindowId=(await chrome.storage.session.get('antc_worker_window')).antc_worker_window??null;
 if(collectorWindowId!=null)try{await chrome.windows.get(collectorWindowId);}catch{collectorWindowId=null;}
 if(collectorWindowId==null){
  const win=await retryTabOperation(()=>chrome.windows.create(searchTabId!=null?{tabId:searchTabId,focused:false,type:'normal'}:{url:'about:blank',focused:false,type:'normal'}));
  collectorWindowId=win.id;
  await chrome.storage.session.set({antc_worker_window:collectorWindowId});
 }else if(searchTabId!=null){
  const tab=await chrome.tabs.get(searchTabId);
  if(tab.windowId!==collectorWindowId)await retryTabOperation(()=>chrome.tabs.move(searchTabId,{windowId:collectorWindowId,index:-1}));
 }
 return collectorWindowId;
}
async function createCollectorTab(url){
 const windowId=await ensureCollectorWindow();
 return retryTabOperation(()=>chrome.tabs.create({url,windowId,active:true}));
}
async function closeCollectorTab(tabId){if(tabId!=null)try{await retryTabOperation(()=>chrome.tabs.remove(tabId));}catch{/* Do not close or alter other browser tabs. */}}

// Short acknowledgements + persisted results avoid holding a message channel open for an entire option scan.
const detailTasks=new Map();
async function collectNewDetail(message,sender,onTab=async()=>{}){
 let tab,response;
 try{
  const id=aliItemId(message.url);
  if(!id)throw new Error('알리 상품번호를 확인하지 못해 상세 수집을 중단했습니다.');
  if(!knownProductIds)await loadKnownProducts();
  if(knownProductIds.has(id))return {rows:[],duplicate:true,excluded:'기존 상품번호 중복 · 상세 수집 생략'};
  const human=(await chrome.storage.session.get("antc_manual_verification")).antc_manual_verification;
  if(human?.resolved&&aliItemId(human.sourceUrl||human.url)===id)try{tab=await chrome.tabs.get(human.tabId);}catch{}
  if(!tab)tab=await createCollectorTab(message.url);await onTab(tab.id);
  await waitComplete(tab.id);
  response=await collectFromTab(tab.id,1,'check',message.choiceConfirmed===true,'new',sender.tab?.id)||{rows:[],error:'상세페이지 응답 없음'};
  if(response.human_verification){const human=(await chrome.storage.session.get("antc_manual_verification")).antc_manual_verification;await chrome.storage.session.set({antc_manual_verification:{...human,sourceUrl:message.url}});}
  return response;
 }catch(error){return {rows:[],error:error.message,retryable:transientTabError(error)};}
 finally{if(!response?.human_verification){await closeCollectorTab(tab?.id);const human=(await chrome.storage.session.get("antc_manual_verification")).antc_manual_verification;if(human?.tabId===tab?.id)await chrome.storage.session.remove("antc_manual_verification");}}
}
chrome.runtime.onMessage.addListener((message,sender,sendResponse)=>{
 if(!['ANTC_DETAIL_START','ANTC_DETAIL_POLL','ANTC_DETAIL_ACK'].includes(message?.type)||!sender.tab?.id)return false;
 const key=`antc_detail_${sender.tab.id}`;
 (async()=>{
  const record=(await chrome.storage.session.get(key))[key];
  if(message.type==='ANTC_DETAIL_ACK'){
   if(record?.requestId===message.requestId&&record.status==='done')await chrome.storage.session.remove(key);
   sendResponse({ok:true});return;
  }
  if(message.type==='ANTC_DETAIL_POLL'){
   if(record?.requestId!==message.requestId){sendResponse({ok:false,error:'수집 연결이 끊겼습니다. 같은 상품을 다시 시도합니다.',retryable:true});return;}
   if(record.status==='done'){sendResponse({ok:true,done:true,response:record.response});return;}
   if(!detailTasks.has(key)){
    await closeCollectorTab(record.tabId);await chrome.storage.session.remove(key);
    sendResponse({ok:false,error:'수집 연결이 끊겼습니다. 같은 상품을 다시 시도합니다.',retryable:true});return;
   }
   sendResponse({ok:true,done:false});return;
  }
  if(record?.requestId===message.requestId){sendResponse({ok:true,requestId:message.requestId});return;}
  if(detailTasks.has(key)){sendResponse({ok:false,error:'이전 상세 수집 작업이 아직 진행 중입니다.',retryable:false});return;}
  if(record?.tabId)await closeCollectorTab(record.tabId);
  const task={requestId:message.requestId,status:'running',startedAt:Date.now(),tabId:null};
  await chrome.storage.session.set({[key]:task});
  // Reserve before replying, so a following poll cannot mistake a live task for a stopped worker.
  detailTasks.set(key,task);
  sendResponse({ok:true,requestId:message.requestId});
  (async()=>{
   try{task.response=await collectNewDetail(message,sender,async tabId=>{task.tabId=tabId;await chrome.storage.session.set({[key]:task});});}
   catch(error){task.response={rows:[],error:error.message,retryable:transientTabError(error)};}
   task.status='done';task.tabId=null;
   try{await chrome.storage.session.set({[key]:task});}finally{detailTasks.delete(key);}
  })().catch(()=>detailTasks.delete(key));
 })().catch(error=>sendResponse({ok:false,error:error.message,retryable:transientTabError(error)}));
 return true;
});

async function pagePayloads(tabId) {
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    func: () => {
      const texts = [];
      let total = 0;
      const add = (value) => {
        if (value == null || total >= 12_000_000) return;
        try {
          const text = typeof value === "string" ? value : JSON.stringify(value);
          if (!text || text.length < 2 || text.length > 8_000_000) return;
          texts.push(text);
          total += text.length;
        } catch { /* ignore non-serializable page data */ }
      };
      for (const name of [
        "runParams", "__INIT_DATA__", "__INITIAL_STATE__", "__NEXT_DATA__",
        "__APOLLO_STATE__", "__AER_DATA__", "__AER_APP_DATA__", "__PRELOADED_STATE__"
      ]) add(window[name]);
      for (const script of document.scripts) {
        const text = script.textContent || "";
        if (/skuPriceList|productSKUPropertyList|availQuantity|skuPropIds/.test(text)) add(text);
      }
      return texts.slice(0, 16);
    },
  });
  return Array.isArray(results?.[0]?.result) ? results[0].result : [];
}

async function sendToManager(rows) {
  const response = await fetch(MANAGER, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ rows, auto_upload: true }),
  });
  let result = {};
  try { result = await response.json(); } catch { /* handled below */ }
  if (!response.ok || !result.ok) throw new Error(result.error || `HTTP ${response.status}`);
  if(knownProductIds)for(const row of rows){const id=aliItemId(row.source_url);if(id)knownProductIds.add(id);}
  return result;
}

async function collectFromTab(tabId, minStock, mode="check", choiceConfirmed=false, collectionMode="existing", progressTabId=null,targetOptions=null) {
  minStock=1;
  let lastError, best, choiceUnconfirmed;
  for (let attempt = 0; attempt < 15; attempt += 1) {
    try {
      const payloads = await pagePayloads(tabId);
      const response = await chrome.tabs.sendMessage(tabId, {
        type: "ANTC_COLLECT_CURRENT",
        minStock,
        mode,
        progressTabId,
        choiceConfirmed,
        collectionMode,
        pagePayloads: payloads,
        targetOptions,
      });
      if(response?.human_verification){await chrome.storage.session.set({antc_manual_verification:{tabId,url:(await chrome.tabs.get(tabId)).url,resolved:false}});return response;}
      if (response?.excluded) return response;
      if (response?.choice_unconfirmed) choiceUnconfirmed=response.error;
      if(response?.option_scan_complete)return response;
      if (response?.rows?.length) {
        const score = response.rows.reduce((n,row)=>n+(typeof row.stock === "number"?2:0)+(row.main_image?1:0),0);
        const bestScore = best?.rows?.reduce((n,row)=>n+(typeof row.stock === "number"?2:0)+(row.main_image?1:0),0) ?? -1;
        if (score > bestScore) best = response;
        if (mode==="images" && response.rows.some(row=>row.main_image)) return response;
        if (response.rows.every(row=>row.discontinued || (typeof row.stock === "number" && row.main_image))) return response;
      }
      if (response?.error) lastError = new Error(response.error);
    } catch (error) { lastError = error; }
    await new Promise((resolve) => setTimeout(resolve, 1000));
  }
  if (best) return best;
  if (choiceUnconfirmed) return {rows:[],excluded:choiceUnconfirmed};
  throw lastError || new Error("알리 상세페이지 로딩 시간이 초과됐습니다.");
}

chrome.runtime.onMessage.addListener((message,sender,sendResponse)=>{
 if(message?.type!=='ANTC_HUMAN_RESUME'||!sender.tab?.id)return false;
 (async()=>{const human=(await chrome.storage.session.get('antc_manual_verification')).antc_manual_verification;if(human)await chrome.storage.session.set({antc_manual_verification:{...human,resolved:true}});sendResponse({ok:true});})().catch(error=>sendResponse({ok:false,error:error.message}));return true;
});
chrome.runtime.onInstalled.addListener(() => {chrome.alarms.clear("antc_stock_sync");});

function waitComplete(tabId) {
  return new Promise(resolve=>{
    let finished=false,timer;
    const finish=(settle=true)=>{if(finished)return;finished=true;chrome.tabs.onUpdated.removeListener(listener);clearTimeout(timer);if(settle)setTimeout(resolve,400);else resolve();};
    const listener=(id,info)=>{if(id===tabId&&info.status==='complete')finish();};
    // Subscribe before checking current state: fast tabs may already have fired complete.
    chrome.tabs.onUpdated.addListener(listener);
    timer=setTimeout(()=>finish(false),20000);
    chrome.tabs.get(tabId).then(tab=>{if(tab.status==='complete')finish();}).catch(()=>finish(false));
  });
}

// Source-stock scheduling lives in the manager; retire the old whole-watchlist sweep.
chrome.alarms.clear("antc_stock_sync");
let browserWorkBusy=false;
let browserGate=Promise.resolve();
function withBrowserGate(fn){const result=browserGate.then(fn);browserGate=result.catch(()=>{});return result;}
async function searchCollectionActive(){
 const human=(await chrome.storage.session.get("antc_manual_verification")).antc_manual_verification;
 if(human&&!human.resolved){
  const expired=Date.now()>(human.expiresAt||0);
  let tab;try{tab=await chrome.tabs.get(human.tabId);}catch{}
  if(!tab||expired){await chrome.storage.session.remove('antc_manual_verification');}
  else if(!human.managerJobId)return true;
 }
 if(detailTasks.size)return true;
 const saved=await chrome.storage.session.get(null);
 for(const [key,job] of Object.entries(saved)){
  if(!key.startsWith('antc_run_'))continue;
  if(job.paused)continue;
  if(Date.now()-(job.updatedAt||job.id||0)>15*60*1000){await chrome.storage.session.remove(key);continue;}
  try{await chrome.tabs.get(Number(key.slice('antc_run_'.length)));return true;}catch{await chrome.storage.session.remove(key);}
 }
 return false;
}

chrome.runtime.onMessage.addListener((message,sender,sendResponse)=>{
  if(message?.type!=="ANTC_DETAIL_PROGRESS")return false;
  chrome.tabs.sendMessage(message.tabId,{type:"ANTC_COLLECTION_PROGRESS",text:message.text}).catch(()=>{});
  return false;
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if(message?.type!=="ANTC_KNOWN_PRODUCTS")return false;
  loadKnownProducts().then(sendResponse).catch(error=>sendResponse({ok:false,error:error.message}));
  return true;
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if(message?.type!=="ANTC_RUN_STATE" || !sender.tab?.id)return false;
  const key=`antc_run_${sender.tab.id}`;
  (async()=>{
    if(message.action==="acquire"){
      await withBrowserGate(async()=>{
        if(browserWorkBusy || (await chrome.storage.session.get('antc_manager_busy_until')).antc_manager_busy_until>Date.now() || await searchCollectionActive()){sendResponse({ok:false,error:"다른 수집·재고 확인 작업이 진행 중입니다. 작업이 끝난 뒤 시작하세요."});return;}
        const windowId=await ensureCollectorWindow(sender.tab.id);
        await chrome.storage.session.set({[key]:{...message.job,paused:false,updatedAt:Date.now(),windowId}});sendResponse({ok:true,windowId});
      });
    }else if(message.action==="save"){
      await chrome.storage.session.set({[key]:{...message.job,updatedAt:Date.now()}});sendResponse({ok:true});
    }else if(message.action==="clear"){
      await chrome.storage.session.remove(key);sendResponse({ok:true});
    }else{const saved=await chrome.storage.session.get(key);sendResponse({ok:true,job:saved[key]||null});}
  })().catch(error=>sendResponse({ok:false,error:error.message}));
  return true;
});
chrome.tabs.onRemoved.addListener(tabId=>chrome.storage.session.remove(`antc_run_${tabId}`).catch(()=>{}));

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "ANTC_SEND_MANAGER") {
    sendToManager(Array.isArray(message.rows) ? message.rows.filter(row => row.stock!==0 && row.choice === true && !row.thrift_mart && !/알뜰\s*마트|Dollar\s*Express|Bundle\s*deals/i.test(`${row.seller || ""} ${row.reason || ""}`)) : [])
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type !== "ANTC_COLLECT_URL") return false;
  collectNewDetail(message,sender).then(sendResponse).catch(error=>sendResponse({rows:[],error:error.message}));
  return true;
});

let managerCheckRunning=false;
function withDeadline(promise,ms,message){let timer;return Promise.race([promise,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error(message)),ms);})]).finally(()=>clearTimeout(timer));}
async function managerRequest(path,body){
 const abort=new AbortController(),timer=setTimeout(()=>abort.abort(),15000);
 try{const r=await fetch('http://127.0.0.1:8765/api/collector/'+path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),signal:abort.signal});const data=await r.json();if(!r.ok||data.ok===false)throw new Error(data.error||'앱 응답 오류');return data;}finally{clearTimeout(timer);}
}
async function processManagerChecks(){
 if(managerCheckRunning||browserWorkBusy)return;
 managerCheckRunning=true;let reserved=false,job=null,results=[],timer,deliveredCount=0,stopped=false,heartbeatBusy=false,lastMessage='상세 확인 중 · 확인값은 순차 저장';
 const heartbeat=async message=>{if(!job)return false;if(message)lastMessage=message;const r=await managerRequest('heartbeat',{id:job.id,completed:deliveredCount,message:lastMessage});stopped=stopped||Boolean(r.stop);return stopped;};
 try{
  reserved=await withBrowserGate(async()=>{if(browserWorkBusy||await searchCollectionActive())return false;browserWorkBusy=true;reserved=true;await chrome.storage.session.set({antc_manager_busy_until:Date.now()+10*60*1000});return true;});
  if(!reserved)return;
  ({job}=await managerRequest('claim',{collector_version:'2.3.22'}));if(!job)return;
  // A slow DOM response must not strand the app lease or the extension gate.
  timer=setInterval(async()=>{if(heartbeatBusy)return;heartbeatBusy=true;try{await heartbeat();}catch{}finally{heartbeatBusy=false;}},15000);
  const groups=new Map();for(const p of job.products){if(!groups.has(p.source_url))groups.set(p.source_url,[]);groups.get(p.source_url).push(p);}
  for(const [url,products] of groups){
   if(await heartbeat('알리 상세페이지 확인 중'))break;
   let tab,rows=[],error='',humanBlocked=false,processedCount=0;
   try{
    tab=await createCollectorTab(url);await waitComplete(tab.id);
    for(let offset=0;offset<products.length;offset+=12){
     if(await heartbeat(`같은 상품 옵션 ${offset}/${products.length} 확인 · 12개씩 분할`))break;
     const batch=products.slice(offset,offset+12);let response;
     for(let attempt=0;attempt<2;attempt++){
      response=await withDeadline(collectFromTab(tab.id,1,job.mode,false,'existing',null,batch),180000,'상세 응답 시간 초과 · 미확인 옵션으로 넘김');
      if(!response.human_verification)break;
      humanBlocked=true;
      await chrome.storage.session.set({antc_manual_verification:{tabId:tab.id,url,sourceUrl:url,resolved:false,managerJobId:job.id,createdAt:Date.now(),expiresAt:Date.now()+30000}});
      if(attempt===1)break;
      await heartbeat('알리 사람 확인 화면 · 15초 후 창을 다시 열어 1회 재시도 · 해결되지 않으면 미확인으로 넘깁니다.');
      // This only waits or reloads the product. It never operates a challenge.
      for(let tick=0;tick<3&&!stopped;tick++){
       await new Promise(resolve=>setTimeout(resolve,5000));
       const human=(await chrome.storage.session.get('antc_manual_verification')).antc_manual_verification;
       if(human?.resolved)break;
      }
      if(stopped)break;
      await closeCollectorTab(tab.id);tab=await createCollectorTab(url);await waitComplete(tab.id);
     }
     if(stopped)break;
     if(response?.human_verification){error='사람 확인 화면 · 창 재접속 2회 후 미확인으로 넘김';break;}
     humanBlocked=false;const batchRows=response?.rows||[];rows.push(...batchRows);error=response?.error||'';
     const saved=await managerRequest('result',{id:job.id,partial:true,results:batch.map(p=>({product_id:p.id,rows:batchRows,error}))});
     stopped=stopped||Boolean(saved.stopped);deliveredCount+=batch.length;processedCount+=batch.length;
     if(error||stopped)break;
    }
   }catch(e){error=e.message;}finally{
    await closeCollectorTab(tab?.id);
    const human=(await chrome.storage.session.get('antc_manual_verification')).antc_manual_verification;
    if(human?.managerJobId===job.id||human?.tabId===tab?.id)await chrome.storage.session.remove('antc_manual_verification');
   }
   const groupResults=(stopped?products.slice(0,processedCount):products).map(p=>({product_id:p.id,rows,error}));results.push(...groupResults);
   const saved=await managerRequest('result',{id:job.id,partial:true,results:groupResults});stopped=stopped||Boolean(saved.stopped);deliveredCount=results.length;
   if(stopped)break;
   if(humanBlocked)await heartbeat('사람 확인이 필요한 상품은 미확인으로 남기고 다음 상품 확인 중');
  }
  await managerRequest('result',{id:job.id,results});
 }catch(error){
  if(job)try{await managerRequest('result',{id:job.id,results});}catch{}
 }finally{
  clearInterval(timer);managerCheckRunning=false;
  if(reserved){browserWorkBusy=false;await chrome.storage.session.remove('antc_manager_busy_until').catch(()=>{});}
 }
}

chrome.alarms.create("antc_manager_checks",{periodInMinutes:0.5});
chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name==="antc_manager_checks")processManagerChecks()});
chrome.runtime.onStartup.addListener(()=>{chrome.alarms.clear("antc_stock_sync");chrome.alarms.create("antc_manager_checks",{periodInMinutes:0.5});});
