(() => {
  'use strict';
  function required(doc,url=''){
    if(/(?:\/punish|\/_____tmd_____\/|\/captcha)(?:[/?]|$)/i.test(url))return true;
    const selectors='#nc_1_wrapper,#nc_2_wrapper,#baxia-dialog-content,[class*="nc-container"],iframe[src*="captcha"],iframe[src*="recaptcha"],iframe[src*="hcaptcha"],iframe[src*="baxia"],iframe[src*="punish"],.g-recaptcha,.h-captcha';
    return [...doc.querySelectorAll(selectors)].some(n=>n.getClientRects().length>0&&!n.closest?.('#antc-panel'));
  }
  window.ANTC_HUMAN_VERIFICATION={required};
})();
